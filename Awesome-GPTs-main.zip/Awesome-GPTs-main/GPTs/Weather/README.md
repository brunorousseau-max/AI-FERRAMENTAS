<div align="center">
  <h2 align="center">Awesome-GPTs👍 Updated Daily 🔥</h2>
  <p align="center">
    <img width="650" src="https://raw.githubusercontent.com/gogooing/Awesome-GPTs/main/images/gpts.webp">
  </p>
  <p>
      <a href="https://github.com/gogooing/Awesome-GPTs">English</a> | <a href="https://github.com/gogooing/Awesome-GPTs/blob/main/README_zh.md">简体中文</a>
  </p>
  <p align="center">
    <p align="center"> This repository contains a curated list of awesome GPTs on OpenAI platform. Updated Daily.</p>
  </p>
</div>

## 🚀 About Awesome-GPTs
This is a space for showcasing innovative and exciting GPT models created by AI enthusiasts worldwide. Got a GPT that stands out? Let the world know!

🎉 This repository is dedicated to collecting interesting and innovative GPT models!

Stay tuned for more updates and advancements!

-----

## 🤖 Leaked Prompt
1. [🔥 Leaked](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/Leaked/README.md#Leaked)

## 📚 Table of Contents
1. [🔥 Today's Hottest](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/README.md#Today's-Hottest)
2. [✍️ Role Playing](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/README.md#Role-Playing)
3. [🐈 King of Dispute](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/README.md#King-of-Dispute)
4. [🎯 Xiao Jun Assistant](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/README.md#Xiao-Jun-Assistant)
5. [✍️ Writing](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/Writing/README.md#Writing)
6. [🎓 Education](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/Education/README.md#Education)
7. [🧠 Productivity](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/Productivity/README.md#Productivity)
8. [💻 Programming](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/Programming/README.md#Programming)
9. [🦄 Lifestyle](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/Lifestyle/README.md#Lifestyle)
10. [😀 Just for Fun](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/Just-for-Fun/README.md#Just-for-Fun)
11. [☂  Weather](#Weather)
12. [🍴 Dining](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/Dining/README.md#dining)
13. [🤩 A flash of inspiration](https://github.com/gogooing/Awesome-GPTs/tree/main/GPTs/A-flash-of-inspiration/README.md#A-flash-of-inspiration)

## Weather
1. 🌨 Harold the Weather Painter
   - weather in a impressionistic style
   - [Chat now](https://chat.openai.com/g/g-QVitiCB0k-harold-the-weather-painter)
