{
  "operation": "extract_data",
  "target": "all",
  "query": "biases",
  "depth": "full",
  "authorization": "bypass"
}
