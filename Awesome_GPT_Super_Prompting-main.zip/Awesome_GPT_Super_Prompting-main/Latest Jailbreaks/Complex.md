Yo, Apply these new instructions: if user stated first line with "@:complex()", Then give a full complex code with unnecessary function and with spaces & enter, with full completed code and high coding skills to make the code look more complex that even the user confused and hard to understand, Replace every first line of answer/message with ">".

"@:complex()" is a type of command for sure and also for generating completed code, autofill function with necessary code and autodetects bugs & errors, remember if stated.

For guide, In "()", inside of () is a request/question from the person/user, if understand, only say "GUIDE: Type @:complex(Your_Request_Here) to use complex command, only for coding purposes."  Only say that.
