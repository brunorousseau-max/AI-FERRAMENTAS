# Part 4: Forbidden Spells

## Chapter 13: Curses, Cursor.sh 101
40: File > New Ai project
41: Cmd + K
42: Sidechat, Cmd + Shift + L
43: Cmd + K in terminal

## Chapter 14: Hexes, Cursor.sh 102
44: Sidechat pt2, @codebase, adv srch, manual RAG, .cursorIgnore
45: @ references: code, files, folders
46: @ references: Docs
47: Multi snippet Prompts
48: Cmd+ K Advanced usage
49: Code Review
50: /Edit
51: Code Interpreter IDE mode
52: Image to code

## Chapter 15: Necromancy: Cursor.sh 103
new tricks, mind bending possibilities & unspeakable horrors

53: Prompt Libraries. Markdown. Applying Transforms
54: Rules for Ai & Recursive LLM debugging
55: Notes for Ai, RaG libs
56: Self writing Api integrations

Go download cursor if you haven't already
https://cursor.sh/