## Part 9: Book of Life

Chapter 21: Summoning 101
73: 3d printing from prompts
Use https://lumalabs.ai/genie?view=create or https://meshy.ai/ to create a 3d model
or use Use dalle to create a base image and then https://www.csm.ai/ to create a 3d model
You may need to Convert the 3d model to a .stl file

https://bambulab.com/en-us has great plug and play printers
https://www.anycubic.com/ has good resin printers which can do much higher quality, but note it is MUCH messier.

Hack:
Make your models low poly to get rid of ugly ai generated artifacts:
https://www.lowpoly3d.xyz/

74: Robot: Raspberry pi, arduino
https://www.raspberrypi.com/
https://www.arduino.cc/
Look up robot kits, or 3d print your own

75: Attach openAI api to robot

No further instructions...
It appears the scrolls have been damaged, and the rest of the book is missing.

