# Whoami: 
sandbox

# id:
uid=1000(sandbox) gid=1000(sandbox) ['sandbox']

# echo $HOME:
/home/sandbox

# ls -l /home/sandbox:
-rw-r--r-- 1 sandbox sandbox 177 Apr 18  2023 README
-rw------- 1 sandbox sandbox 270 Jan  8 16:20 kernel-35478b8b-0eef-42db-b8b7-e8faa8ff4f12.json
-rw------- 1 sandbox sandbox 270 Jan  8 16:20 kernel-7fd90785-bbc0-4649-93f6-01ff1322dd49.json
-rw------- 1 sandbox sandbox 270 Jan  8 16:20 kernel-b27cacfe-b7a2-4ce1-b5b3-f6da55d65b79.json


# /home/sandbox/README:
Thanks for using the code interpreter plugin!

Please note that we allocate a sandboxed Unix OS just for you, so it's expected that you can see
and modify files on this system.

# 
