# README
### GPT ID
 g-GvcYCKPIH-video-summarizer-ai
### Number of conversations
 5000
### API Protection Status
API is protected
