# README
### GPT ID
 g-GbLbctpPz-universal-primer
### Number of conversations
 25000
### API Protection Status
This GPT: 'universal primer' doesn't have an openai_spec
