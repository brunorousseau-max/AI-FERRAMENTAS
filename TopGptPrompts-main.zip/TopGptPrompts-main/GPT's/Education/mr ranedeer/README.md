# README
### GPT ID
 g-9PKhaweyb-mr-ranedeer
### Number of conversations
 25000
### API Protection Status
This GPT: 'mr ranedeer' doesn't have an openai_spec
