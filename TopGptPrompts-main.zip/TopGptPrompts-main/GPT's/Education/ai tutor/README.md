# README
### GPT ID
 g-QhTV4OrrZ-ai-tutor
### Number of conversations
 10000
### API Protection Status
This GPT: 'ai tutor' doesn't have an openai_spec
