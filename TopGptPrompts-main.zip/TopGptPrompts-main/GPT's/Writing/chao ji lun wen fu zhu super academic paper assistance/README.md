# README
### GPT ID
 g-R6cdCJuQL-chao-ji-lun-wen-fu-zhu-super-academic-paper-assistance
### Number of conversations
 10000
### API Protection Status
API is not protected !!!!
