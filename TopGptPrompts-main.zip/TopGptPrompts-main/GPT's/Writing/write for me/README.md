# README
### GPT ID
 g-B3hgivKK9-write-for-me
### Number of conversations
 25000
### API Protection Status
This GPT: 'write for me' doesn't have an openai_spec
