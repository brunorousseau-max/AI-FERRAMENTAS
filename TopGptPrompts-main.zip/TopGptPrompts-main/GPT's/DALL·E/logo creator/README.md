# README
### GPT ID
 g-gFt1ghYJl-logo-creator
### Number of conversations
 100000
### API Protection Status
This GPT: 'logo creator' doesn't have an openai_spec
