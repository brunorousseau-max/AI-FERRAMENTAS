# README
### GPT ID
 g-9qWC0oyBd-super-describe
### Number of conversations
 50000
### API Protection Status
This GPT: 'super describe' doesn't have an openai_spec
