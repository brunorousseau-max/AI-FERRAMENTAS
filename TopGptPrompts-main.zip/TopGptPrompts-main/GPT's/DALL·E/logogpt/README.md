# README
### GPT ID
 g-z61XG6t54-logogpt
### Number of conversations
 25000
### API Protection Status
This GPT: 'logogpt' doesn't have an openai_spec
