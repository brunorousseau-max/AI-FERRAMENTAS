# README
### GPT ID
 g-ucpsGCQHZ-professor-synapse
### Number of conversations
 10000
### API Protection Status
This GPT: 'professor synapse' doesn't have an openai_spec
