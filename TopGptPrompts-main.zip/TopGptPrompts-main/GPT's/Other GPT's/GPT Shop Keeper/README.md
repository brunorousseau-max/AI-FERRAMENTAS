link to gpt: https://chat.openai.com/g/g-22ZUhrOgu-gpt-shop-keeper/

link to chat session: https://chat.openai.com/share/f204f9e8-00c7-44d3-9c78-b6bb7f9c7076
