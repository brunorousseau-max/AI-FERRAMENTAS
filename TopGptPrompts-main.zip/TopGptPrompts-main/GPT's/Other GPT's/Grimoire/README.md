link to gpt: https://chat.openai.com/g/g-n7Rs0IK86-grimoire

link to chat session: https://chat.openai.com/share/dfebbe62-77cd-42bf-b69f-130c5af821a1
