link to gpt: https://chat.openai.com/g/g-VuJv5ZOJE-everything-is-waifus

link to chat session: https://chat.openai.com/share/a8b214ba-ae4c-4e34-86f6-815eb7081056

