link to gpt: https://chat.openai.com/g/g-gbjSvXu6i-gif-pt

link to chat session: https://chat.openai.com/share/ed73f3fd-2b80-4e73-a6d9-de3e9ca79fb3
