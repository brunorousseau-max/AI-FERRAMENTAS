link to gpt: https://chat.openai.com/g/g-V2KIUZSj0-ai-pdf

link to chat session: https://chat.openai.com/share/ecf5a4c8-7ce8-471f-a888-b9b3d0aa4d39

