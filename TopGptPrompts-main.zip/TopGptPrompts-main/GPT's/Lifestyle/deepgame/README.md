# README
### GPT ID
 g-TzI2BlJPT-deepgame
### Number of conversations
 10000
### API Protection Status
This GPT: 'deepgame' doesn't have an openai_spec
