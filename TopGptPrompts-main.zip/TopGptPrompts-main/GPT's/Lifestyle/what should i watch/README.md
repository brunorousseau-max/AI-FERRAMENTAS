# README
### GPT ID
 g-Gm9cCA5qg-what-should-i-watch
### Number of conversations
 10000
### API Protection Status
This GPT: 'what should i watch' doesn't have an openai_spec
