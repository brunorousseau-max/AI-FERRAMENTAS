# README
### GPT ID
 g-WxckXARTP-astrology-birth-chart-gpt
### Number of conversations
 10000
### API Protection Status
API is not protected !!!!
