# README
### GPT ID
 g-1zMekbWTA-tattoo-gpt
### Number of conversations
 10000
### API Protection Status
This GPT: 'tattoo gpt' doesn't have an openai_spec
