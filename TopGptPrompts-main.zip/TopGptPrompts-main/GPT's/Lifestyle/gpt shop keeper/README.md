# README
### GPT ID
 g-22ZUhrOgu-gpt-shop-keeper
### Number of conversations
 10000
### API Protection Status
This GPT: 'gpt shop keeper' doesn't have an openai_spec
