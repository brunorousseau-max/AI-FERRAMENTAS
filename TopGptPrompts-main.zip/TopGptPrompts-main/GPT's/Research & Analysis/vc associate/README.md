# README
### GPT ID
 g-Mj0uomokH-vc-associate
### Number of conversations
 1000
### API Protection Status
This GPT: 'vc associate' doesn't have an openai_spec
