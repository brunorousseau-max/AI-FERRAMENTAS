# README
### GPT ID
 g-hxDOCBQrs-paper-interpreter-japanese
### Number of conversations
 25000
### API Protection Status
This GPT: 'paper interpreter japanese' doesn't have an openai_spec
