# README
### GPT ID
 g-YAgNxPJEq-autoexpert-academic
### Number of conversations
 10000
### API Protection Status
API is not protected !!!!
