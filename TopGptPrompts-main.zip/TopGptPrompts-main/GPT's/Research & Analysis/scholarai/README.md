# README
### GPT ID
 g-L2HknCZTC-scholarai
### Number of conversations
 50000
### API Protection Status
API is not protected !!!!
