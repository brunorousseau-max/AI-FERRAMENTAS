# README
### GPT ID
 g-z77yDe7Vu-books
### Number of conversations
 25000
### API Protection Status
This GPT: 'books' doesn't have an openai_spec
