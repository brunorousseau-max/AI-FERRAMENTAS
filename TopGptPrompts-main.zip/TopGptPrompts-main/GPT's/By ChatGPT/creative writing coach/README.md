# README
### GPT ID
 g-lN1gKFnvL-creative-writing-coach
### Number of conversations
 unkown
### API Protection Status
This GPT: 'creative writing coach' doesn't have an openai_spec
