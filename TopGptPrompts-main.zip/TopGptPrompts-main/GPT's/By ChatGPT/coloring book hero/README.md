# README
### GPT ID
 g-DerYxX7rA-coloring-book-hero
### Number of conversations
 unkown
### API Protection Status
This GPT: 'coloring book hero' doesn't have an openai_spec
