# README
### GPT ID
 g-2fkFE8rbu-dall-e
### Number of conversations
 unkown
### API Protection Status
This GPT: 'dall e' doesn't have an openai_spec
