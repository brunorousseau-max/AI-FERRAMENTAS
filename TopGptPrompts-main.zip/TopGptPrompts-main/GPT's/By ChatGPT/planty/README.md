# README
### GPT ID
 g-6PKrcgTBL-planty
### Number of conversations
 unkown
### API Protection Status
This GPT: 'planty' doesn't have an openai_spec
