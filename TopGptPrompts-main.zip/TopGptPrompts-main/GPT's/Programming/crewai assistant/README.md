# README
### GPT ID
 g-qqTuUWsBY-crewai-assistant
### Number of conversations
 5000
### API Protection Status
This GPT: 'crewai assistant' doesn't have an openai_spec
