# README
### GPT ID
 g-hz8Pw1quF-screenshot-to-code-gpt
### Number of conversations
 10000
### API Protection Status
This GPT: 'screenshot to code gpt' doesn't have an openai_spec
