# README
### GPT ID
 g-n7Rs0IK86-grimoire
### Number of conversations
 200000
### API Protection Status
This GPT: 'grimoire' doesn't have an openai_spec
