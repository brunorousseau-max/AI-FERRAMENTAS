# README
### GPT ID
 g-pTF23RJ6f-autoexpert-dev
### Number of conversations
 25000
### API Protection Status
This GPT: 'autoexpert dev' doesn't have an openai_spec
