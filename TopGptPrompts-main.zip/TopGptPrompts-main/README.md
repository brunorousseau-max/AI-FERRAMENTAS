# TopGptPrompts
has prompts of some gpt's , uses openai api to get the top performing gpt's , see their openapi spec and prints if they are protected by a api key or not.

## architecture:
each gpt is in a folder with his name, inside the folder there is the full leaked prompt with what he is constructed, and the full conversation with which i aquired the prompt.

with these prompts you can use them, and even modify them to create even better gpts.

## GPT Prompts

| Name                   |
|-----------------       |
| Grimoire               |
| GPT Shop Keeper        |
| Evolution Chamber      |
| Everything is Waifus   |
| AI PDF                 |
| Gif-PT                 |
