# Fuzzers

The purpose of this crate is to contains all the handmade "fuzzer" we may need.
