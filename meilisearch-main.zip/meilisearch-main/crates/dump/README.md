```
dump
├── indexes
│   ├── cattos
│   │   ├── documents.jsonl
│   │   └── settings.json
│   └── doggos
│       ├── documents.jsonl
│       └── settings.json
├── instance-uid.uuid
├── keys.jsonl
├── metadata.json
├── tasks
│   ├── update_files
│   │   └── [task_id].jsonl
│   └── queue.jsonl
└── batches
    └── queue.jsonl
```
