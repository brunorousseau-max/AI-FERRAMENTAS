# Reverse engineering prompts
