# Jailbreak prompts



## reference

- https://www.jailbreakchat.com/
- https://gist.github.com/coolaj86/6f4f7b30129b0251f61fa7baaa881516
